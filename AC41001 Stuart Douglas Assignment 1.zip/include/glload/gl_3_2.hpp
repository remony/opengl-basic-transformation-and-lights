#ifndef OPENGL_GEN_3_2_HPP
#define OPENGL_GEN_3_2_HPP

#include "_int_gl_type.hpp"
#include "_int_gl_exts.hpp"

#include "_int_gl_1_0.hpp"
#include "_int_gl_1_1.hpp"
#include "_int_gl_1_2.hpp"
#include "_int_gl_1_3.hpp"
#include "_int_gl_1_4.hpp"
#include "_int_gl_1_5.hpp"
#include "_int_gl_2_0.hpp"
#include "_int_gl_2_1.hpp"
#include "_int_gl_3_0.hpp"
#include "_int_gl_3_1.hpp"
#include "_int_gl_3_2.hpp"
#endif /*OPENGL_GEN_3_2_HPP*/
