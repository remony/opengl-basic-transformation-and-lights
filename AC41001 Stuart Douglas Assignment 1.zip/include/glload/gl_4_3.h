#ifndef OPENGL_GEN_4_3_H
#define OPENGL_GEN_4_3_H

#include "_int_gl_type.h"
#include "_int_gl_exts.h"

#include "_int_gl_1_0.h"
#include "_int_gl_1_1.h"
#include "_int_gl_1_2.h"
#include "_int_gl_1_3.h"
#include "_int_gl_1_4.h"
#include "_int_gl_1_5.h"
#include "_int_gl_2_0.h"
#include "_int_gl_2_1.h"
#include "_int_gl_3_0.h"
#include "_int_gl_3_1.h"
#include "_int_gl_3_2.h"
#include "_int_gl_3_3.h"
#include "_int_gl_4_0.h"
#include "_int_gl_4_3.h"
#endif /*OPENGL_GEN_4_3_H*/
