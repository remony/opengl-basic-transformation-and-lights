This is a 'modified' version of SOIL. See https://github.com/kbranigan/Simple-OpenGL-Image-Library/issues/8 
for this issue.
I have simply removed the extensions checks which will be fine for any modern (4.x) OpenGL.

However, feel free to use an alternative way of loading images for textures.