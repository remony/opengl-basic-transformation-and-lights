_______________________________________
|     Keys   |         Function       |
|_____________________________________|
|				Camera				              	|
|_____________________________________|
|    Q, E    | Speed up/down gears    |
|      R     | Reset Speed/position   |
|  Up arrow  |      Look Up           |
| Down arrow |      Look Down         |
| Left arrow |      Look Left         |
| Right arrow|      Look Right        |
|    - / _   |       Zoom Out         |
|    = / +   |       Zoom In          |
|      A     |       Pan Left         |
|      D     |       Pan Right        |
|      S     |       Pan Down         |
|      W     |       Pan Up           |
|_____________________________________|
|	   Control individual model      	|
|_____________________________________|
|      M     |  Toggle between models |
|      I     |     Move up            |
|      K     |     Move Down          |
|      J     |     Move Left          |
|      L     |     Move Right         |
|      P     |     Move Back          |
|      O     |     Move Forward       |
|      U     |     Scale Up           |
|      Y     |     Scale Down         |
|_____________________________________|
|	   Light Source Controls           	|
|_____________________________________|
|      5     |     Move Down          |
|      6     |     Move Up            |
|      7     |     Move Left          |
|      8     |     Move Right         |
|      9     |     Scale Forward      |
|      0     |     Scale Back         |
|_____________________________________|
|	      DRAW MODE                  	|
|_____________________________________|
|      N     |   Switch draw mode     |
_______________________________________
