#pragma once
class keyboardHandler
{
public:
	keyboardHandler();
	~keyboardHandler();

	handleControls()
};

