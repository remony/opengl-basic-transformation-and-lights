#pragma once
class inputHandler
{
public:
	inputHandler();
	~inputHandler();
};


